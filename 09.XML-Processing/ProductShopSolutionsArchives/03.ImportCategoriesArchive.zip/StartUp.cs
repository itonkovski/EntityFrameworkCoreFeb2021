﻿using System.IO;
using System.Linq;
using System.Xml.Serialization;
using ProductShop.Data;
using ProductShop.Dtos.Import;
using ProductShop.Models;
using ProductShop.XmlHelper;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var context = new ProductShopContext();
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            //01.ImportUsers
            //var usersXml = File.ReadAllText("./Datasets/users.xml");
            //System.Console.WriteLine(ImportUsers(context, usersXml));

            //02.ImportProducts
            //var usersXml = File.ReadAllText("./Datasets/users.xml");
            //var productsXml = File.ReadAllText("./Datasets/products.xml");
            //ImportUsers(context, usersXml);
            //System.Console.WriteLine(ImportProducts(context, productsXml));

            var usersXml = File.ReadAllText("./Datasets/users.xml");
            var productsXml = File.ReadAllText("./Datasets/products.xml");
            var categoriesXml = File.ReadAllText("./Datasets/categories.xml");
            ImportUsers(context, usersXml);
            ImportProducts(context, productsXml);
            System.Console.WriteLine(ImportCategories(context, categoriesXml));
        }

        //01.ImportUsers
        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            //Basic way of deserializing the input
            //var xmlSerializer = new XmlSerializer(typeof(UsersInputModel[]),
            //    new XmlRootAttribute("Users"));

            //var textReader = new StringReader(inputXml);

            //var usersDto = xmlSerializer
            //    .Deserialize(textReader) as UsersInputModel[];

            //Using XmlConverter created by StoyanShopov
            const string root = "Users";

            var usersDto = XmlConverter
                .Deserializer<UsersInputModel>(inputXml, root);

            var users = usersDto
                .Select(u => new User
            {
                FirstName = u.FirstName,
                LastName = u.LastName,
                Age = u.Age
            })
            .ToList();

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Count()}";
        }

        //02.ImportProducts
        public static string ImportProducts(ProductShopContext context, string inputXml)
        {
            const string root = "Products";

            var productsDto = XmlConverter
                .Deserializer<ProductsInputModel>(inputXml, root);

            var products = productsDto
                .Select(p => new Product
            {
                Name = p.Name,
                Price = p.Price,
                SellerId = p.SellerId,
                BuyerId = p.BuyerId
            })
            .ToList();

            context.Products.AddRange(products);
            context.SaveChanges();

            return $"Successfully imported {products.Count()}";
        }

        public static string ImportCategories(ProductShopContext context, string inputXml)
        {
            const string root = "Categories";

            var categoriesDto = XmlConverter
                .Deserializer<CategoriesInputModel>(inputXml, root);

            var categories = categoriesDto
                .Where(c => c.Name != null)
                .Select(c => new Category
            {
                Name = c.Name
            })
            .ToList();

            context.Categories.AddRange(categories);
            context.SaveChanges();

            return $"Successfully imported {categories.Count()}";
        }
    }
}