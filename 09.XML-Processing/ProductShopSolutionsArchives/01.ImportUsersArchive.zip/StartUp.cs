﻿using System.IO;
using System.Linq;
using System.Xml.Serialization;
using ProductShop.Data;
using ProductShop.Dtos.Import;
using ProductShop.Models;
using ProductShop.XmlHelper;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var context = new ProductShopContext();
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            var usersXml = File.ReadAllText("./Datasets/users.xml");

            //01.ImportUsers
            System.Console.WriteLine(ImportUsers(context, usersXml));
        }

        //01.ImportUsers
        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            //Basic way
            //var xmlSerializer = new XmlSerializer(typeof(UsersInputModel[]),
            //    new XmlRootAttribute("Users"));

            //var textReader = new StringReader(inputXml);

            //var usersDto = xmlSerializer
            //    .Deserialize(textReader) as UsersInputModel[];

            //Using XmlConverter created by StoyanShopov
            const string root = "Users";

            var usersDto = XmlConverter
                .Deserializer<UsersInputModel>(inputXml, root);

            var users = usersDto.Select(u => new User
            {
                FirstName = u.FirstName,
                LastName = u.LastName,
                Age = u.Age
            })
            .ToList();

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Count()}";
        }
    }
}