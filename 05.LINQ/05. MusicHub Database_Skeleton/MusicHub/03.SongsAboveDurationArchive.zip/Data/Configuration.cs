﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=localhost;User Id = SA;Password = Qawsed12;Database=MusicHub";
        
    }
}
