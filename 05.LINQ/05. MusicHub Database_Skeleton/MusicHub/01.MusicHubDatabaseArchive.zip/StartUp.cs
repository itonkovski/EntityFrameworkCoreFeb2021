﻿namespace MusicHub
{
    using System;
    using System.Linq;

    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            MusicHubDbContext context = 
                new MusicHubDbContext();

            DbInitializer.ResetDatabase(context);

            //Test your solutions here
        }

        public static string ExportAlbumsInfo(MusicHubDbContext context, int producerId)
        {
            //var albums = context
            //    .Album
            //    .Where(x => x.ProducerId == producerId)
            //    .Select(x => new
            //    {
            //        albName = x.Name,
            //        releaseDate = x.ReleaseDate,
            //        prodName = x.ProducerId.Name
            //    })

            throw new NotImplementedException();
        }

        public static string ExportSongsAboveDuration(MusicHubDbContext context, int duration)
        {
            throw new NotImplementedException();
        }
    }
}
