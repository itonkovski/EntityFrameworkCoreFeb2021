﻿namespace BookShop
{
    using System;
    using System.Globalization;
    using System.Linq;
    using System.Text;
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            //DbInitializer.ResetDatabase(db);

            //1.AgeRestriction
            //string command = Console.ReadLine();
            //Console.WriteLine(GetBooksByAgeRestriction(db,command));

            //2.GoldenBooks
            //Console.WriteLine(GetGoldenBooks(db));

            //3.BooksByPrice
            //Console.WriteLine(GetBooksByPrice(db));

            //4.NotReleasedIn
            //int year = int.Parse(Console.ReadLine());
            //Console.WriteLine(GetBooksNotReleasedIn(db, year));

            //5.BookTitlesByCategory
            //var input = Console.ReadLine();
            //Console.WriteLine(GetBooksByCategory(db, input));

            var date = Console.ReadLine();
            Console.WriteLine(GetBooksReleasedBefore(db, date));
        }

        //1.AgeRestriction
        public static string GetBooksByAgeRestriction(BookShopContext contex, string command)
        {
            var ageRestriction = Enum.Parse<AgeRestriction>(command, true);

            var books = contex
                .Books
                .Where(b => b.AgeRestriction == ageRestriction)
                .Select(b => b.Title)
                .OrderBy(t => t)
                .ToList();

            return string.Join(Environment.NewLine, books);
        }

        //2.GoldenBooks
        public static string GetGoldenBooks(BookShopContext context)
        {
            var books = context
                .Books
                .AsEnumerable()
                .Where(b => b.EditionType.ToString() == "Gold"
                            && b.Copies < 5000)
                .OrderBy(b => b.BookId)
                .Select(b => b.Title)
                .ToList();

            return string.Join(Environment.NewLine, books);
        }

        //3.BooksByPrice
        public static string GetBooksByPrice(BookShopContext context)
        {
            var books = context
                .Books
                .Where(b => b.Price > 40)
                .OrderByDescending(b => b.Price)
                .Select(b => new
                {
                    bookTitle = b.Title,
                    bookPrice = b.Price
                })
                .ToList();

            var sb = new StringBuilder();

            foreach (var book in books)
            {
                sb
                    .AppendLine($"{book.bookTitle} - ${book.bookPrice:F2}");
            }

            return sb.ToString().TrimEnd();
        }

        //4.NotReleasedIn
        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            var books = context
                .Books
                .Where(b => b.ReleaseDate.Value.Year != year)
                .OrderBy(b => b.BookId)
                .Select(x => x.Title)
                .ToList();

            return string.Join(Environment.NewLine, books);
        }

        //5.BookTitlesByCategory
        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            var listOfCategories = input
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.ToLower())
                .ToArray();

            var books = context
                .Books
                .Include(x => x.BookCategories)
                .ThenInclude(x => x.Category)
                .ToArray()
                .Where(b => b.BookCategories
                    .Any(category => listOfCategories.Contains(category.Category.Name.ToLower())))
                .Select(b => b.Title)
                .OrderBy(title => title)
                .ToArray();

            return string.Join(Environment.NewLine, books);
        }

        public static string GetBooksReleasedBefore(BookShopContext context, string date)
        {
            var books = context
                .Books
                .Where(b => b.ReleaseDate < DateTime.ParseExact(date, "dd-MM-yyyy", CultureInfo.CurrentCulture))
                .OrderByDescending(b => b.ReleaseDate)
                .Select(x => new
                {
                    bookTitle = x.Title,
                    editType = x.EditionType,
                    bookPrice = x.Price
                })
                .ToList();

            var sb = new StringBuilder();

            foreach (var book in books)
            {
                sb
                    .AppendLine($"{book.bookTitle} - {book.editType} - ${book.bookPrice:F2}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
