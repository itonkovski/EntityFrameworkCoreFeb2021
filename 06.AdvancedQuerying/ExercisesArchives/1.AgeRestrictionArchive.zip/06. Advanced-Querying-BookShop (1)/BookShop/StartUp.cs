﻿namespace BookShop
{
    using System;
    using System.Linq;
    using BookShop.Models.Enums;
    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);

            string command = Console.ReadLine();
            Console.WriteLine(GetBooksByAgeRestriction(db,command));
        }

        public static string GetBooksByAgeRestriction(BookShopContext contex, string command)
        {
            var ageRestriction = Enum.Parse<AgeRestriction>(command, true);

            var books = contex
                .Books
                .Where(b => b.AgeRestriction == ageRestriction)
                .Select(b => b.Title)
                .OrderBy(t => t)
                .ToList();

            return string.Join(Environment.NewLine, books);
        }
    }
}
