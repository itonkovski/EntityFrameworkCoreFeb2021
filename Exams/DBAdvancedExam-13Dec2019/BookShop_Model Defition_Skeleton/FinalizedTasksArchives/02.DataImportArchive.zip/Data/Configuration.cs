﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost;Database=BookShopExamPrep;User Id = SA; Password = Qawsed12";
    }
}