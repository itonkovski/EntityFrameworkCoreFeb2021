﻿namespace VaporStore.Data.Models.Enums
{
    public enum CardType
    {
        Debit = 10,
        Credit = 20
    }
}