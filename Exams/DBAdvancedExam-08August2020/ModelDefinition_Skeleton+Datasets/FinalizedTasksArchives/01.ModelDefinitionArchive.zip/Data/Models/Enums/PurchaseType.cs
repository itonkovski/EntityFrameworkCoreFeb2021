﻿using System;
namespace VaporStore.Data.Models.Enums
{
    public enum PurchaseType
    {
        Retail = 10,
        Digital = 20
    }
}
