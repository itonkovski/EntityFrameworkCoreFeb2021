﻿using System;
using System.Globalization;
using System.Linq;
using System.Text;
using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using SoftUni.Models;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var context = new SoftUniContext();

            //03.EmployeeFullInformation
            //Console.WriteLine(GetEmployeesFullInformation(context));

            //04.EmployeeswithSalaryOver50000
            //Console.WriteLine(GetEmployeesWithSalaryOver50000(context));

            //05.EmployeesFromResearchAndDevelopment
            //Console.WriteLine(GetEmployeesFromResearchAndDevelopment(context));

            //06.AddingANewAddressAndUpdatingEmployee
            //Console.WriteLine(AddNewAddressToEmployee(context));

            Console.WriteLine(GetEmployeesInPeriod(context));
        }

        //03.EmployeeFullInformation
        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            var employees = context.Employees
                .OrderBy(x => x.EmployeeId)
                .Select(x => new
                {
                    firstName = x.FirstName,
                    lastName = x.LastName,
                    middleName = x.MiddleName,
                    jobTitle = x.JobTitle,
                    salary = x.Salary
                })
                .ToList();

            var sb = new StringBuilder();

            foreach (var employee in employees)
            {
                sb
                    .AppendLine($"{employee.firstName} {employee.lastName} {employee.middleName} {employee.jobTitle} {employee.salary:F2}");
            }

            return sb.ToString().TrimEnd();
        }

        //04.EmployeeswithSalaryOver50000
        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            var employees = context.Employees
                .Where(x => x.Salary > 50000)
                .Select(x => new
                {
                    firstName = x.FirstName,
                    salary = x.Salary
                })
                .OrderBy(x => x.firstName)
                .ToList();

            var sb = new StringBuilder();

            foreach (var employee in employees)
            {
                sb
                    .AppendLine($"{employee.firstName} - {employee.salary:F2}");
            }

            return sb.ToString().TrimEnd();
        }

        //05.EmployeesFromResearchAndDevelopment
        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            var employees = context.Employees
                .Where(x => x.Department.Name == "Research and Development")
                .Select(x => new
                {
                    firstName = x.FirstName,
                    lastName = x.LastName,
                    departmentName = x.Department.Name,
                    salary = x.Salary
                })
                .OrderBy(x => x.salary)
                .ThenByDescending(x => x.firstName)
                .ToList();

            var sb = new StringBuilder();

            foreach (var employee in employees)
            {
                sb
                    .AppendLine($"{employee.firstName} {employee.lastName} from {employee.departmentName} - ${employee.salary:F2}");
            }

            return sb.ToString().TrimEnd();
        }

        //06.AddingANewAddressAndUpdatingEmployee
        public static string AddNewAddressToEmployee(SoftUniContext context)
        {
            var employee = context.Employees
                .FirstOrDefault(x => x.LastName == "Nakov");

            employee.Address = new Address
            {
                AddressText = "Vitoshka 15",
                TownId = 4
            };

            context.SaveChanges();

            var addressesToDisplay = context.Employees
                .OrderByDescending(x => x.AddressId)
                .Take(10)
                .Select(x => new
                {
                    output = x.Address.AddressText
                })
                .ToList();

            var sb = new StringBuilder();

            foreach (var address in addressesToDisplay)
            {
                sb
                    .AppendLine($"{address.output}");
            }

            return sb.ToString().TrimEnd();
        }

        public static string GetEmployeesInPeriod(SoftUniContext context)
        {
            var employees = context.Employees
                .Include(x => x.EmployeesProjects)
                .ThenInclude(x => x.Project)
                .Where(x => x.EmployeesProjects.Any(p => p.Project.StartDate.Year >= 2001
                                                         && p.Project.StartDate.Year <= 2003))
                .Select(x => new
                {
                    empFirstName = x.FirstName,
                    empLastName = x.LastName,
                    managerFirstName = x.Manager.FirstName,
                    managerLastName = x.Manager.LastName,
                    projects = x.EmployeesProjects.Select(p => new
                    {
                        projectName = p.Project.Name,
                        startDate = p.Project.StartDate,
                        endDate = p.Project.EndDate
                    })
                })
                .Take(10)
                .ToList();

            var sb = new StringBuilder();

            foreach (var employee in employees)
            {
                sb
                    .AppendLine($"{employee.empFirstName} {employee.empLastName} - Manager: {employee.managerFirstName} {employee.managerLastName}");

                foreach (var project in employee.projects)
                {
                    var projectsStartDate = project.startDate.ToString("M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture);
                    var projectsEndDate = project.endDate is null ? "not finished" : project.endDate.Value.ToString("M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture);

                    sb
                        .AppendLine($"--{project.projectName} - {projectsStartDate} - {projectsEndDate}");
                }
            }

            return sb.ToString().TrimEnd();
        }
    }
}
